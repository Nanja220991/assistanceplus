-- DropForeignKey
ALTER TABLE `fichiers` DROP FOREIGN KEY `Fichiers_id_patient_fkey`;
